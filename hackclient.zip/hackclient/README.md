# Hack Client (Fabric 1.21.11, Loader 0.19.5)

## Build
1. Install JDK 21.
2. Create the Gradle wrapper (one time). Either:
   a) Install Gradle (https://gradle.org/install) and run:  gradle wrapper --gradle-version 9.2.1
   b) or generate the official 1.21.11 template at https://fabricmc.net/develop , and copy its
      `gradlew`, `gradlew.bat` and `gradle/wrapper/gradle-wrapper.jar` into this folder.
3. ./gradlew build   (Windows: gradlew.bat build)  ->  build/libs/hackclient-1.0.0.jar
   ./gradlew runClient launches a dev client.

Put the jar in .minecraft/mods with Fabric API 0.141.3+1.21.11.

## Commands
/hc list                      modules and their state
/hc toggle <module>           Fly | Speed | Fullbright | AutoSprint | BaseFinder
/hc scan                      one-off scan: top 10 densest chunks around you
/hc threshold <n>             how dense counts as a base (default 10)
/hc bases                     last 15 finds (saved in config/hackclient/bases.txt)

## BaseFinder score
chest 2, barrel 2, shulker 5, hopper 2, furnace 1, ender chest 1. 3+ shulkers always counts.
It only sees chunks your client has loaded (your render distance), so move around.
Natural structures also have chests/spawners, so some hits are false positives.
