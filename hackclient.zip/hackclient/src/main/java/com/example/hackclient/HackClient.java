package com.example.hackclient;

import com.example.hackclient.command.HcCommand;
import com.example.hackclient.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public class HackClient implements ClientModInitializer {
    public static final ModuleManager MODULES = new ModuleManager();

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.player != null && mc.level != null) MODULES.tick();
        });
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                HcCommand.register(dispatcher));
    }
}
