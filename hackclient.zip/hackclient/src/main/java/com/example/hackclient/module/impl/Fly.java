package com.example.hackclient.module.impl;

import com.example.hackclient.module.Module;
import net.minecraft.client.player.LocalPlayer;

public class Fly extends Module {
    public Fly() { super("Fly", "Creative-style flight (servers with anti-cheat will flag this)."); }

    @Override
    public void onTick() {
        LocalPlayer p = mc.player;
        if (p == null) return;
        p.getAbilities().mayfly = true;
        p.getAbilities().setFlyingSpeed(0.08f);
    }

    @Override
    protected void onDisable() {
        LocalPlayer p = mc.player;
        if (p == null || p.isCreative() || p.isSpectator()) return;
        p.getAbilities().mayfly = false;
        p.getAbilities().flying = false;
        p.getAbilities().setFlyingSpeed(0.05f);
    }
}
