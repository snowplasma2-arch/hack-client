package com.example.hackclient.module.impl;

import com.example.hackclient.basefinder.BaseHit;
import com.example.hackclient.basefinder.BaseLog;
import com.example.hackclient.basefinder.BaseScanner;
import com.example.hackclient.module.Module;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;

import java.util.HashSet;
import java.util.Set;

/** Rescans loaded chunks every 5 seconds and reports (and logs) new likely-base chunks. */
public class BaseFinder extends Module {
    private final Set<Long> seen = new HashSet<>();
    private ClientLevel lastLevel;
    private int ticks;

    public BaseFinder() { super("BaseFinder", "Alerts you to chunks dense with chests, barrels, shulkers etc."); }

    @Override
    protected void onEnable() { seen.clear(); ticks = 99; }

    @Override
    public void onTick() {
        if (mc.level == null || mc.player == null) return;
        if (mc.level != lastLevel) { lastLevel = mc.level; seen.clear(); }
        if (++ticks < 100) return;
        ticks = 0;

        for (BaseHit hit : BaseScanner.scan(mc)) {
            if (!hit.isBase(BaseScanner.threshold)) continue;
            if (!seen.add(ChunkPos.asLong(hit.chunkX(), hit.chunkZ()))) continue;

            String dim = mc.level.dimension() == Level.NETHER ? "nether"
                    : mc.level.dimension() == Level.END ? "end" : "overworld";
            String line = "[" + dim + "] " + hit.coords() + " score=" + hit.score() + " (" + hit.summary() + ")";
            mc.player.displayClientMessage(Component.literal("[BaseFinder] " + line), false);
            BaseLog.save(line);
        }
    }
}
