package com.example.hackclient.module.impl;

import com.example.hackclient.module.Module;
import net.minecraft.client.player.LocalPlayer;

public class AutoSprint extends Module {
    public AutoSprint() { super("AutoSprint", "Sprints automatically while moving forward."); }

    @Override
    public void onTick() {
        LocalPlayer p = mc.player;
        if (p == null) return;
        if (mc.options.keyUp.isDown() && !p.isSprinting() && !p.horizontalCollision
                && p.getFoodData().getFoodLevel() > 6) {
            p.setSprinting(true);
        }
    }
}
