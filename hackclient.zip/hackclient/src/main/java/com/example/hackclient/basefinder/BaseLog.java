package com.example.hackclient.basefinder;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.List;

public final class BaseLog {
    private BaseLog() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("hackclient").resolve("bases.txt");
    }

    public static void save(String line) {
        try {
            Path f = file();
            Files.createDirectories(f.getParent());
            Files.writeString(f, line + System.lineSeparator(),
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ignored) {
        }
    }

    public static List<String> tail(int n) {
        try {
            List<String> all = Files.readAllLines(file());
            return all.subList(Math.max(0, all.size() - n), all.size());
        } catch (IOException e) {
            return List.of();
        }
    }
}
