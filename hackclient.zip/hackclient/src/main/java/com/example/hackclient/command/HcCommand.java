package com.example.hackclient.command;

import com.example.hackclient.HackClient;
import com.example.hackclient.basefinder.BaseHit;
import com.example.hackclient.basefinder.BaseLog;
import com.example.hackclient.basefinder.BaseScanner;
import com.example.hackclient.module.Module;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;

import java.util.List;

public class HcCommand {
    private static void say(FabricClientCommandSource s, String msg) {
        s.sendFeedback(Component.literal(msg));
    }

    public static void register(CommandDispatcher<FabricClientCommandSource> d) {
        d.register(ClientCommandManager.literal("hc")

            .then(ClientCommandManager.literal("list").executes(ctx -> {
                for (Module m : HackClient.MODULES.all()) {
                    say(ctx.getSource(), (m.isEnabled() ? "[ON]  " : "[OFF] ") + m.getName() + " - " + m.getDescription());
                }
                return 1;
            }))

            .then(ClientCommandManager.literal("toggle")
                .then(ClientCommandManager.argument("module", StringArgumentType.word())
                    .suggests((ctx, b) -> SharedSuggestionProvider.suggest(
                        HackClient.MODULES.all().stream().map(Module::getName).toList(), b))
                    .executes(ctx -> {
                        String name = StringArgumentType.getString(ctx, "module");
                        return HackClient.MODULES.byName(name).map(m -> {
                            m.toggle();
                            say(ctx.getSource(), m.getName() + " " + (m.isEnabled() ? "enabled" : "disabled"));
                            return 1;
                        }).orElseGet(() -> {
                            say(ctx.getSource(), "Unknown module: " + name);
                            return 0;
                        });
                    })))

            // /hc scan : one-off scan of everything currently loaded, top 10 chunks
            .then(ClientCommandManager.literal("scan").executes(ctx -> {
                List<BaseHit> hits = BaseScanner.scan(Minecraft.getInstance());
                if (hits.isEmpty()) {
                    say(ctx.getSource(), "No storage blocks in loaded chunks.");
                    return 0;
                }
                say(ctx.getSource(), "Top chunks (threshold " + BaseScanner.threshold + "):");
                for (BaseHit h : hits.stream().limit(10).toList()) {
                    say(ctx.getSource(), (h.isBase(BaseScanner.threshold) ? "* " : "  ")
                            + h.coords() + "  score " + h.score() + "  (" + h.summary() + ")");
                }
                return 1;
            }))

            // /hc threshold <n> : how dense a chunk must be to count as a base
            .then(ClientCommandManager.literal("threshold")
                .then(ClientCommandManager.argument("n", IntegerArgumentType.integer(1, 500))
                    .executes(ctx -> {
                        BaseScanner.threshold = IntegerArgumentType.getInteger(ctx, "n");
                        say(ctx.getSource(), "Base threshold set to " + BaseScanner.threshold);
                        return 1;
                    })))

            // /hc bases : last 15 saved finds
            .then(ClientCommandManager.literal("bases").executes(ctx -> {
                List<String> lines = BaseLog.tail(15);
                if (lines.isEmpty()) {
                    say(ctx.getSource(), "No saved bases yet. Enable BaseFinder and explore.");
                    return 0;
                }
                lines.forEach(l -> say(ctx.getSource(), l));
                return 1;
            })));
    }
}
