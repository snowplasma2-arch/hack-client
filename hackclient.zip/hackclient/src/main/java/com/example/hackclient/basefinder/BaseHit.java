package com.example.hackclient.basefinder;

import net.minecraft.core.BlockPos;

public record BaseHit(int chunkX, int chunkZ, int score,
                      int chests, int barrels, int shulkers, int enderChests,
                      int hoppers, int furnaces, int spawners, BlockPos sample) {

    public boolean isBase(int threshold) {
        return score >= threshold || shulkers >= 3;
    }

    public String coords() {
        return sample.getX() + " " + sample.getY() + " " + sample.getZ();
    }

    public String summary() {
        StringBuilder sb = new StringBuilder();
        append(sb, chests, "chest");
        append(sb, barrels, "barrel");
        append(sb, shulkers, "shulker");
        append(sb, enderChests, "ender chest");
        append(sb, hoppers, "hopper");
        append(sb, furnaces, "furnace");
        append(sb, spawners, "spawner");
        return sb.toString();
    }

    private static void append(StringBuilder sb, int n, String what) {
        if (n <= 0) return;
        if (sb.length() > 0) sb.append(", ");
        sb.append(n).append(' ').append(what).append(n > 1 ? "s" : "");
    }
}
