package com.example.hackclient.basefinder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.EnderChestBlockEntity;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Scans every chunk the client currently has loaded and scores it by how many
 * storage-type block entities it contains. Dense chunks are likely player builds.
 * Natural structures (dungeons, mineshafts, villages, bastions) also contain chests
 * and spawners, so expect some false positives.
 */
public final class BaseScanner {
    public static volatile int threshold = 10;

    private BaseScanner() {}

    public static List<BaseHit> scan(Minecraft mc) {
        List<BaseHit> out = new ArrayList<>();
        ClientLevel level = mc.level;
        LocalPlayer p = mc.player;
        if (level == null || p == null) return out;

        int pcx = p.blockPosition().getX() >> 4;
        int pcz = p.blockPosition().getZ() >> 4;
        int rd = mc.options.getEffectiveRenderDistance();

        for (int dx = -rd; dx <= rd; dx++) {
            for (int dz = -rd; dz <= rd; dz++) {
                int cx = pcx + dx, cz = pcz + dz;
                if (!level.hasChunk(cx, cz)) continue;
                BaseHit hit = analyse(level.getChunk(cx, cz), cx, cz);
                if (hit != null) out.add(hit);
            }
        }
        out.sort(Comparator.comparingInt(BaseHit::score).reversed());
        return out;
    }

    private static BaseHit analyse(LevelChunk chunk, int cx, int cz) {
        int chests = 0, barrels = 0, shulkers = 0, ender = 0, hoppers = 0, furnaces = 0, spawners = 0;
        BlockPos sample = null;

        for (BlockEntity be : chunk.getBlockEntities().values()) {
            if (be instanceof ChestBlockEntity) chests++;
            else if (be instanceof BarrelBlockEntity) barrels++;
            else if (be instanceof ShulkerBoxBlockEntity) shulkers++;
            else if (be instanceof EnderChestBlockEntity) ender++;
            else if (be instanceof HopperBlockEntity) hoppers++;
            else if (be instanceof AbstractFurnaceBlockEntity) furnaces++;
            else if (be instanceof SpawnerBlockEntity) spawners++;
            else continue;
            if (sample == null) sample = be.getBlockPos();
        }
        if (sample == null) return null;

        int score = chests * 2 + barrels * 2 + shulkers * 5 + ender + hoppers * 2 + furnaces;
        if (score <= 0 && spawners == 0) return null;
        return new BaseHit(cx, cz, score, chests, barrels, shulkers, ender, hoppers, furnaces, spawners, sample);
    }
}
