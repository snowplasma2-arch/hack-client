package com.example.hackclient.module;

import com.example.hackclient.module.impl.AutoSprint;
import com.example.hackclient.module.impl.BaseFinder;
import com.example.hackclient.module.impl.Fly;
import com.example.hackclient.module.impl.Fullbright;
import com.example.hackclient.module.impl.Speed;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        modules.add(new Fly());
        modules.add(new Speed());
        modules.add(new Fullbright());
        modules.add(new AutoSprint());
        modules.add(new BaseFinder());
    }

    public List<Module> all() { return modules; }

    public Optional<Module> byName(String name) {
        return modules.stream().filter(m -> m.getName().equalsIgnoreCase(name)).findFirst();
    }

    public void tick() {
        for (Module m : modules) {
            if (m.isEnabled()) m.onTick();
        }
    }
}
