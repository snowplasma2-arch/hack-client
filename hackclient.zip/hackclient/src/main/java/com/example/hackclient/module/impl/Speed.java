package com.example.hackclient.module.impl;

import com.example.hackclient.module.Module;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

public class Speed extends Module {
    private static final double FACTOR = 1.06;
    private static final double MAX_HORIZONTAL = 0.6;

    public Speed() { super("Speed", "Boosts horizontal movement speed."); }

    @Override
    public void onTick() {
        LocalPlayer p = mc.player;
        if (p == null) return;
        boolean moving = mc.options.keyUp.isDown() || mc.options.keyDown.isDown()
                || mc.options.keyLeft.isDown() || mc.options.keyRight.isDown();
        if (!moving) return;
        Vec3 v = p.getDeltaMovement();
        double h = Math.hypot(v.x, v.z);
        if (h > 0.001 && h < MAX_HORIZONTAL) {
            p.setDeltaMovement(v.x * FACTOR, v.y, v.z * FACTOR);
        }
    }
}
